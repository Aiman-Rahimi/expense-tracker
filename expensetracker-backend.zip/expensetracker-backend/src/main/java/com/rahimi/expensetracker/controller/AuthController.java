package com.rahimi.expensetracker.controller;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import com.rahimi.expensetracker.model.User;
import com.rahimi.expensetracker.service.CustomUserDetails;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    @GetMapping("/success")
    public CustomUserDetails loginSuccess(@AuthenticationPrincipal CustomUserDetails user) {
        return user;
    }

    @GetMapping("/fail")
    public String loginFail() {
        return "Login failed";
    }

    @GetMapping("/logout-success")
    public String logoutSuccess() {
        return "Logout success";
    }
}
